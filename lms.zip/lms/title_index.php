				
								<div class="row-fluid">

						<div class="span12">
						
						</div>	
													
							</div>
							<div class="row-fluid">

						<div class="span4">
						<img class="index_logo" src="admin/images/cdaclogo.png">
						</div>	
						<div class="span8">
						
								<div class="title">
							<p class="chmsc"><marquee style="color: tomato ; font-family:imapct ;font-size:30px">C-DAC HYDERABAD</marquee> </p>
							<h3>

							<p style ="color:#f3f3f3; font-size:25 px; ">E - Learning</p>
						
							</h3>		
						</div>
			
						</div>							
							</div>
				
				<div class="row-fluid">

						<div class="span12">
						<br>
								<div class="motto">
												<p>We in C-DAC do -: :</p>
												<p>Applications...Research...and Technology...!!!</p>
												
								</div>		
						</div>		
				</div>