<center>
		<footer>
		
		<p>C-DAC HYDERABAD E-Learning  SYSTEM Copyright 2018</p>
			<!-- <p>Programmed by: Abhishek</p> -->
		</footer>
</center>

