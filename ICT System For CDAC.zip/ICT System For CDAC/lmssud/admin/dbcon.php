<?php
mysql_select_db('cdac',mysql_connect('localhost','root',''))or die(mysql_error());
?>