<center>
		<footer>
		
		<p>C-DAC HYDERABAD E-Learning Copyright 2018</p>
			
		</footer>
</center>

