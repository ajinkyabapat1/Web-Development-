				
								<div class="row-fluid">

						<div class="span12">
						
						</div>	
													
							</div>
							<div class="row-fluid">

						<div class="span4">
						<img class="index_logo" src="admin/images/cdaclogo.png">
						</div>	
						<div class="span8">
						
								<div class="title">
							
							
							<h2>
							<p class="chmsc" > <b><marquee>C-DAC HYDERABAD</marquee>E -Learning</p>
						
							</h2>		
						</div>
			
						</div>							
							</div>
				
				<div class="row-fluid">

						<div class="span12">
						<br>
								<div class="motto">
												<p> We in C-DAC HYDERABAD Do...</p>
												<p>Research...Application..and Technology!!</p>
												
								</div>		
						</div>		
				</div>