<?php include('header_dashboard.php'); ?>
    <body id="class_div">
		<?php include('navbar_about.php'); ?>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span12" id="content">
                     <div class="row-fluid">
                        <!-- block -->
                        <div class="block">
								<div class="navbar navbar-inner block-header">
									<div id="" class="muted pull-right"><a href="index.php"><i class="icon-arrow-left"></i> Back</a></div>
								</div>
                            <div class="block-content collapse in">
							<h3>Developers</h3>
							<hr>
                                <div class="span3">
										<center>
										<img id="developers" src="admin/images/aju.jpg" class="img-circle">
										<hr>
										<p>Name: Ajinkya Bapat</p>
										<p>Address: Hyderabad</p>
										<p>Email: ajinkyabapat1@gmail.com</p>
										<p>Position: Project Manager</p>
										</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/sud.jpg" class="img-circle">
								<hr>
																				<p>Name: Sudhanshu Tayade </p>

										<p>Address: Hyderabad</p>
										<p>Email: sudhaansh@gmail.com</p>
										<p>Position: Programmer</p>
								</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/KAPIL.jpg" class="img-circle">
								<hr>
												<p>Name: Kapil Garte </p>
										<p>Address: Hyderabad</p>
										<p>Email: gartekapil3732@gmail.com</p>
										<p>Position: FrontEnd Developer</p>
								</center>
								</div>
                                <div class="span3">
															<center>
								<img id="developers" src="admin/images/pari.jpg" class="img-circle">
								<hr>
												<p>Name: Parish Mali </p>
										<p>Address: Hyderabad</p>
										<p>Email: maliparish@gmail.com</p>
										<p>Position: Backend  Developer</p>
								</center>
								</div>
								<div class="span3">
															<center>
								<img id="developers" src="admin/images/viv.jpg" class="img-circle">
								<hr>
												<p>Name: vivek Mahalpure </p>
										<p>Address: Hyderabad</p>
										<p>Email: vivek@gmail.com</p>
										<p>Position: UI Designer</p>
								</center>
								</div>
                            </div>
                        </div>
                        <!-- /block -->
                    </div>
                </div>
            </div>
		<?php include('footer.php'); ?>
        </div>
		<?php include('script.php'); ?>
    </body>
</html>